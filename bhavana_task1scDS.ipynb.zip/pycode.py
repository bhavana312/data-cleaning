import pandas as pd
import numpy as np

df = pd.read_csv("dataset.csv")

print("=== Null Values in Each Column ===")
print(df.isnull().sum())

def detect_outliers_iqr(data, column):
    if pd.api.types.is_numeric_dtype(data[column]):
        Q1 = data[column].quantile(0.25)
        Q3 = data[column].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        outliers = data[(data[column] < lower_bound) | (data[column] > upper_bound)]
        return outliers
    else:
        return pd.DataFrame()

numeric_cols = df.select_dtypes(include=[np.number]).columns
print("\n=== Outliers Detected Using IQR ===")
for col in numeric_cols:
    outliers = detect_outliers_iqr(df, col)
    if not outliers.empty:
        print(f"\nOutliers in '{col}':")
        if "Unique ID" in outliers.columns:
            print(outliers[["Unique ID", col]])
        else:
            print(outliers[[col]])

print("\n=== Duplicate Rows ===")
duplicate_rows = df[df.duplicated()]
print(duplicate_rows)

print("\n=== Invalid Values Based on Known Ranges ===")
invalid_age = df[(df["Age"] < 0) | (df["Age"] > 120)]
if not invalid_age.empty:
    print("\nInvalid Ages:")
    if "Unique ID" in df.columns:
        print(invalid_age[["Unique ID", "Age"]])
    else:
        print(invalid_age[["Age"]])

invalid_sleep = df[(df["Sleeping hours"] < 0) | (df["Sleeping hours"] > 24)]
if not invalid_sleep.empty:
    print("\nInvalid Sleeping Hours:")
    if "Unique ID" in df.columns:
        print(invalid_sleep[["Unique ID", "Sleeping hours"]])
    else:
        print(invalid_sleep[["Sleeping hours"]])

invalid_IQ = df[(df["IQ"] < 50) | (df["IQ"] > 200)]
if not invalid_IQ.empty:
    print("\nInvalid IQ Scores:")
    if "Unique ID" in df.columns:
        print(invalid_IQ[["Unique ID", "IQ"]])
    else:
        print(invalid_IQ[["IQ"]])

invalid_gender = df[~df['Gender'].isin(['Male', 'Female', np.nan])]
if not invalid_gender.empty:
    print("\nInvalid Gender Values:")
    if "Unique ID" in df.columns:
        print(invalid_gender[["Unique ID", "Gender"]])
    else:
        print(invalid_gender[["Gender"]])

print("\n=== Data Processing Steps ===")
df_cleaned = df.drop_duplicates().copy()
numeric_cols_cleaned = df_cleaned.select_dtypes(include=[np.number]).columns
df_cleaned[numeric_cols_cleaned] = df_cleaned[numeric_cols_cleaned].fillna(df_cleaned[numeric_cols_cleaned].median())

for col in df_cleaned.select_dtypes(include="object").columns:
    if df_cleaned[col].isnull().any() and not df_cleaned[col].isnull().all():
        mode_value = df_cleaned[col].mode()
        if not mode_value.empty:
            df_cleaned[col] = df_cleaned[col].fillna(mode_value[0])

print("Missing values filled and duplicates removed.")

print("\n=== Cleaned DataFrame (First 5 Rows) ===")
print(df_cleaned.head())
